<template>
  <div></div>
</template>

<script>
export default {
  name: 'MyTest',
  data() {
    return {}
  },

  created() {},

  methods: {}
}
</script>

<style scoped></style>
